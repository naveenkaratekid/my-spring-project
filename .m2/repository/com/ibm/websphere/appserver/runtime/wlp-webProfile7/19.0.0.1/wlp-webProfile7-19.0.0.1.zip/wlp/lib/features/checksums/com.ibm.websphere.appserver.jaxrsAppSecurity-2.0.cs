#Fri Jan 25 02:42:31 GMT 2019
lib/com.ibm.ws.jaxrs.2.0.security_1.0.24.jar=caef978085e48e61700c4939055adff4
lib/features/com.ibm.websphere.appserver.jaxrsAppSecurity-2.0.mf=ef91b524db2d8a450a062259ba55c67f
