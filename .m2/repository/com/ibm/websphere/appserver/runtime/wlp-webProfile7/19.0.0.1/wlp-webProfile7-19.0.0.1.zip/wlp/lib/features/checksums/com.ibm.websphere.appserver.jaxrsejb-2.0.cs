#Fri Jan 25 02:42:30 GMT 2019
lib/features/com.ibm.websphere.appserver.jaxrsejb-2.0.mf=32e80984ba0499e1f8f30baf673a3d85
lib/com.ibm.ws.jaxrs.2.0.ejb_1.0.24.jar=5b9d247f719b27f732e045da7ae8d900
