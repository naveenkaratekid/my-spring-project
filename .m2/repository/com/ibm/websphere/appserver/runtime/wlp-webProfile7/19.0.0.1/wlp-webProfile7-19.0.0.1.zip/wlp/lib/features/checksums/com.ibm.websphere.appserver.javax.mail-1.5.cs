#Fri Jan 25 02:42:30 GMT 2019
lib/features/com.ibm.websphere.appserver.javax.mail-1.5.mf=6b5117036ef1570614b8c5e06b265970
lib/com.ibm.ws.com.sun.mail.javax.mail.1.5_1.5.24.jar=7c32a7bc731e131df7fe0b66d486b12b
