#Fri Jan 25 02:42:31 GMT 2019
lib/features/com.ibm.websphere.appserver.injection-1.0.mf=82bba7faffb5e43cc5901bb367ab5cd8
lib/com.ibm.ws.injection_1.0.24.jar=c796146232ea7a8b8a239c82d739c061
