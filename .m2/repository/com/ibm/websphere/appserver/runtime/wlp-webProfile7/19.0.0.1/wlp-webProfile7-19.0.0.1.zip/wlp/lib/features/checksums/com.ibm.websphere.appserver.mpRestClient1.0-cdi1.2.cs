#Fri Jan 25 02:42:30 GMT 2019
lib/com.ibm.ws.microprofile.rest.client.cdi_1.0.24.jar=3fbdac0cae45b321c006ef9d3eda907a
lib/features/com.ibm.websphere.appserver.mpRestClient1.0-cdi1.2.mf=47a62d79112de695a74587bf258a995b
