#Fri Jan 25 02:42:30 GMT 2019
lib/com.ibm.ws.jpa.container.eclipselink_1.0.24.jar=4d10f31b44c1036d3cab58456230712d
lib/features/com.ibm.websphere.appserver.jpa-2.1.mf=bd2d75ba1959e94ee5b937008e4e96ed
dev/api/third-party/com.ibm.websphere.appserver.thirdparty.eclipselink_1.0.24.jar=0124529e4c537801a4853f02f0a3ee53
