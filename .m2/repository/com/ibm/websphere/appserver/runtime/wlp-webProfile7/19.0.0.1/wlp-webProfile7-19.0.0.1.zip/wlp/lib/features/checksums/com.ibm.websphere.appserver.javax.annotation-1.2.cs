#Fri Jan 25 02:42:30 GMT 2019
lib/features/com.ibm.websphere.appserver.javax.annotation-1.2.mf=b21e987c64638a06961451caa18a8b53
dev/api/spec/com.ibm.websphere.javaee.annotation.1.2_1.0.24.jar=b5c441e2a26d0b1f77fdfc5d8af5ddd7
