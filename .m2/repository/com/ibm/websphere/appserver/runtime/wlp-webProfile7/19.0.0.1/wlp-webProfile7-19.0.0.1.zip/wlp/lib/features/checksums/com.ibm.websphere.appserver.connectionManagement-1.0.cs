#Fri Jan 25 02:42:31 GMT 2019
lib/com.ibm.ws.jca.cm_1.0.24.jar=9d0281f212cfcb5760326f1ae44e6f9f
lib/features/com.ibm.websphere.appserver.connectionManagement-1.0.mf=344dd43e3aabef3547ccc864faa574d7
