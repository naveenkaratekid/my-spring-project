#Fri Jan 25 02:42:31 GMT 2019
dev/spi/ibm/javadoc/com.ibm.websphere.appserver.spi.httptransport_4.1-javadoc.zip=acdeaf985c0f498a252f2fc1cac6427e
lib/com.ibm.ws.transport.http_1.0.24.jar=c79755f27100e8ef754d122a3891281e
dev/spi/ibm/com.ibm.websphere.appserver.spi.httptransport_4.1.24.jar=f386bb2b6b1e428b0da706af824f472d
lib/features/com.ibm.websphere.appserver.httptransport-1.0.mf=f45a2bc240742cb7ed1e006b546791a9
