#Fri Jan 25 02:42:30 GMT 2019
lib/features/com.ibm.websphere.appserver.mpConfig-1.1.mf=332bccfb8af4f0f2c3e5bc702301ab6b
lib/com.ibm.ws.require.java8_1.0.24.jar=c8bbea2b91a087dbf95bbd66e7392c4d
lib/com.ibm.ws.microprofile.config_2.0.24.jar=f0d37546493226db1868c8dd3b884668
lib/com.ibm.ws.microprofile.config.1.1.services_1.0.24.jar=8867fcbc4b332cc4b8ec79a92ff3a855
lib/com.ibm.ws.org.apache.commons.lang3_1.0.24.jar=1e190283a07edde3c5ad8ffb98949d63
