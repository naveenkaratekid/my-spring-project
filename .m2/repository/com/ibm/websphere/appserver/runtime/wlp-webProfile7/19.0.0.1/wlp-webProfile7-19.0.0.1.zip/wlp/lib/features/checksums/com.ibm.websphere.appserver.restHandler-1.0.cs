#Fri Jan 25 02:42:30 GMT 2019
lib/features/com.ibm.websphere.appserver.restHandler-1.0.mf=701e09bb47f87c61442ed9363bc50285
lib/com.ibm.ws.org.joda.time.1.6.2_1.0.24.jar=443317f3c615bd1b638c7171253b2f41
dev/spi/ibm/javadoc/com.ibm.websphere.appserver.spi.restHandler_2.0-javadoc.zip=dfabe37ae52fa6dccd4a0c9c49b2b3d3
lib/com.ibm.ws.rest.handler_1.0.24.jar=46c63e662d4171e6b9d66cd799460b39
dev/spi/ibm/com.ibm.websphere.appserver.spi.restHandler_2.0.24.jar=1d36eae70a7eff5bc5c759dd633dd6be
lib/com.ibm.websphere.jsonsupport_1.0.24.jar=d4d2bc7046bdaa97950a428b0be6d1fc
lib/com.ibm.websphere.rest.handler_1.0.24.jar=9d31e231fc830c1c44954b6a1a645592
