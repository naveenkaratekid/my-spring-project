#Fri Jan 25 02:42:30 GMT 2019
lib/com.ibm.ws.cdi.transaction_1.0.24.jar=8cd3300768a08d211dbd9bba23cf744e
lib/features/com.ibm.websphere.appserver.cdi1.2-transaction1.2.mf=a4133ca7ef9db22d99420b48e3cca825
