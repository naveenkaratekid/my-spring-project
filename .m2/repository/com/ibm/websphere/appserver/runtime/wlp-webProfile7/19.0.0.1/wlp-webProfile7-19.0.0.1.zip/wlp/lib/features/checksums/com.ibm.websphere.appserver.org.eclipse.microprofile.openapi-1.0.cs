#Fri Jan 25 02:42:30 GMT 2019
dev/api/stable/com.ibm.websphere.org.eclipse.microprofile.openapi.1.0_1.0.24.jar=134b7ce1dcaef944660902ad1d035c23
lib/features/com.ibm.websphere.appserver.org.eclipse.microprofile.openapi-1.0.mf=f9da9b17da7eab7d36b6917c7cb74335
