#Fri Jan 25 02:42:29 GMT 2019
lib/features/com.ibm.websphere.appserver.ejbLiteCore-1.0.mf=32ad830828ef797c765c93535ba903fa
lib/com.ibm.ws.ejbcontainer.session_1.0.24.jar=58dd043bbb377348e4551dcd0f2d51ba
