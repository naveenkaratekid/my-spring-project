#Fri Jan 25 02:42:30 GMT 2019
lib/com.ibm.ws.jaxrs.2.0.beanvalidation_1.0.24.jar=736a93a07f6bf53c6c7bebc771c330a4
lib/features/com.ibm.websphere.appserver.jaxrsBeanValidation-2.0.mf=149c4d48e423a114cadbdc078f9600e4
