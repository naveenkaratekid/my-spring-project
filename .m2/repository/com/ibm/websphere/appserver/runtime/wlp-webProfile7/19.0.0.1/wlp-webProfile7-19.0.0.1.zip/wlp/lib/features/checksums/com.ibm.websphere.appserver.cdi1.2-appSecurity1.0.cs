#Fri Jan 25 02:42:30 GMT 2019
lib/features/com.ibm.websphere.appserver.cdi1.2-appSecurity1.0.mf=df2a9fd3ea04053fb8b4f8cc6af57171
lib/com.ibm.ws.cdi.security_1.0.24.jar=03006728116feb4b2859b850b157db2d
