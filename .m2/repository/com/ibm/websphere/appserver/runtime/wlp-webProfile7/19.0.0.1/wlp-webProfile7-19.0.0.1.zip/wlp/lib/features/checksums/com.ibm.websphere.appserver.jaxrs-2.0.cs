#Fri Jan 25 02:42:30 GMT 2019
lib/features/com.ibm.websphere.appserver.jaxrs-2.0.mf=430a8aadda60ac28c7d9a7199a9a6812
