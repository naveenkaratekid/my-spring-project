#Fri Jan 25 02:42:31 GMT 2019
lib/features/com.ibm.websphere.appserver.internal.slf4j-1.7.7.mf=b130fde4668294f462573dea2e94faa9
lib/com.ibm.ws.org.slf4j.api.1.7.7_1.0.24.jar=daf55609bd1ed511cbbbb96ff889c357
lib/com.ibm.ws.org.slf4j.jdk14.1.7.7_1.0.24.jar=6b26e6fa08b72880568842e077d33fe7
