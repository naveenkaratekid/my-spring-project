#Fri Jan 25 02:42:30 GMT 2019
lib/com.ibm.ws.javaee.persistence.2.1_1.0.24.jar=5343cf8bee2a8e988e955f362a8b6992
lib/features/com.ibm.websphere.appserver.javax.persistence.base-2.1.mf=79dee18e408ada1d55ae685f22626bd9
