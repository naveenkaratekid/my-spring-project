#Fri Jan 25 02:42:30 GMT 2019
lib/features/com.ibm.websphere.appserver.javax.jaxrs-2.0.mf=754da4c13a991a28926281373f4327f3
dev/api/ibm/com.ibm.websphere.appserver.api.jaxrs20_1.0.24.jar=ef795e9e71ffd2e114abd4df85c087ac
dev/api/spec/com.ibm.websphere.javaee.jaxb.2.2_1.0.24.jar=bc9690ca6a5cdc83c7a93c330b014c30
dev/api/spec/com.ibm.websphere.javaee.jaxrs.2.0_1.0.24.jar=72a593c4501bb17b0afff1d287dc9447
dev/api/spec/com.ibm.websphere.javaee.activation.1.1_1.0.24.jar=6280c20f67004d51036022aa0e0ae5f5
dev/api/ibm/javadoc/com.ibm.websphere.appserver.api.jaxrs20_1.0-javadoc.zip=dbff54d266906d1f2a1b4bc987ac1b88
