#Fri Jan 25 02:42:29 GMT 2019
dev/api/spec/com.ibm.websphere.javaee.interceptor.1.1_1.0.24.jar=2f4d525d7a16c3abb7ed409bf8853bd0
lib/features/com.ibm.websphere.appserver.javax.interceptor-1.1.mf=20337756263ee6f7fdc23ff1e54d30ff
