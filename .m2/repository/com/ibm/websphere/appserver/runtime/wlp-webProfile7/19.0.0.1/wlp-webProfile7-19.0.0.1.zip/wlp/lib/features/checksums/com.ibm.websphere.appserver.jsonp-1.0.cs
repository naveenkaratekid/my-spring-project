#Fri Jan 25 02:42:32 GMT 2019
lib/com.ibm.ws.org.glassfish.json.1.0_1.0.24.jar=b9c07565ddaf030610856f9a7551b578
lib/features/com.ibm.websphere.appserver.jsonp-1.0.mf=8f3a06a2e3be025a556ba40bac60dbb7
dev/api/spec/com.ibm.websphere.javaee.jsonp.1.0_1.0.24.jar=5a229539f7467e5441609298d44b6f1c
