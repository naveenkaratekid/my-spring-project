#Fri Jan 25 02:42:30 GMT 2019
lib/features/com.ibm.websphere.appserver.javax.annotation-1.1.mf=24dfab5a6e9bd61f9854200a47e7f68a
dev/api/spec/com.ibm.websphere.javaee.annotation.1.1_1.0.24.jar=433dc3eb0d7ea032db24bea64f037ba8
