#Fri Jan 25 02:42:31 GMT 2019
lib/features/com.ibm.websphere.appserver.javax.connector.internal-1.6.mf=30bc4f2fe2a5bb0e5ac2014c66e88a4b
dev/api/spec/com.ibm.websphere.javaee.connector.1.6_1.0.24.jar=3e4a33b9aaf65b0b132b2f9ee80d1050
