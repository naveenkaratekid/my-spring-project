#Fri Jan 25 02:42:31 GMT 2019
lib/com.ibm.ws.org.apache.geronimo.osgi.registry.1.1_1.0.24.jar=6ba1c47df85c9b9a25b5a1588b763c88
dev/api/spec/com.ibm.websphere.javaee.jaxb.2.2_1.0.24.jar=bc9690ca6a5cdc83c7a93c330b014c30
lib/com.ibm.ws.jaxb.tools.2.2.10_1.0.24.jar=8385d8a95aacec9567b86630ada89119
dev/api/spec/com.ibm.websphere.javaee.activation.1.1_1.0.24.jar=6280c20f67004d51036022aa0e0ae5f5
lib/features/com.ibm.websphere.appserver.internal.optional.jaxb-2.2.mf=6b9a8d6eb6557f1499dca3f05f5e99a6
