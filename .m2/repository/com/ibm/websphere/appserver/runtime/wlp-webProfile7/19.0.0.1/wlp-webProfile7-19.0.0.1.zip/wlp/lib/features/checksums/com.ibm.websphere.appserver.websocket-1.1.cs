#Fri Jan 25 02:42:30 GMT 2019
dev/api/spec/com.ibm.websphere.javaee.websocket.1.1_1.0.24.jar=2307cbad47556735f8dd1216af4ede49
lib/features/com.ibm.websphere.appserver.websocket-1.1.mf=6366817566d034661118ed6ca6fc9cab
dev/api/ibm/com.ibm.websphere.appserver.api.wsoc_1.0.24.jar=2eca6cf92329b1fdd2f0576c09d9382b
dev/api/ibm/javadoc/com.ibm.websphere.appserver.api.wsoc_1.0-javadoc.zip=d24620c1131054d0270bec082f1fdd9d
lib/com.ibm.ws.wsoc.1.1_1.0.24.jar=39ad524214c286a6fa490ede301b6cc9
lib/com.ibm.ws.wsoc_1.0.24.jar=672d14f2b212a18af95eea24b4bfd9b7
