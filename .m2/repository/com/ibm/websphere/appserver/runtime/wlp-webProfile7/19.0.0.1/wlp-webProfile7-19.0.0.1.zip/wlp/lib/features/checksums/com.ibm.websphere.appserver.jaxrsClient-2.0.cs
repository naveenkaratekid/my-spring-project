#Fri Jan 25 02:42:31 GMT 2019
lib/features/com.ibm.websphere.appserver.jaxrsClient-2.0.mf=f284b0d2e5ba1d5569983224fa068fdf
lib/com.ibm.ws.jaxrs.2.0.client_1.0.24.jar=88facde9d2dc9d94b54f7c53c2847ef8
