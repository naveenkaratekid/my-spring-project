#Fri Jan 25 02:42:30 GMT 2019
lib/features/com.ibm.websphere.appserver.anno-1.0.mf=a15ba2c00acc695de629de4baa2b87b6
lib/com.ibm.ws.anno_1.0.24.jar=cbca26ef42e0ead2e060060b9f6ad479
dev/spi/ibm/com.ibm.websphere.appserver.spi.anno_1.1.24.jar=98dbdd1a9a25797327304c6e3bb04924
dev/spi/ibm/javadoc/com.ibm.websphere.appserver.spi.anno_1.1-javadoc.zip=b2a92c2df53f251c53016a9e09bf4c8b
