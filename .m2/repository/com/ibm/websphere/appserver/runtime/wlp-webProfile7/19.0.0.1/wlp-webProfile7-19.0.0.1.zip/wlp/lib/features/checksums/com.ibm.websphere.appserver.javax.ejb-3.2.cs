#Fri Jan 25 02:42:31 GMT 2019
dev/api/spec/com.ibm.websphere.javaee.ejb.3.2_1.0.24.jar=772422786e724167040537c2f4a534a2
lib/features/com.ibm.websphere.appserver.javax.ejb-3.2.mf=10578fd2ad32b5af5b147341722a784a
