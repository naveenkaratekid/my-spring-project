#Fri Jan 25 02:42:29 GMT 2019
lib/com.ibm.ws.cdi.1.2.ejb_1.0.24.jar=5a7b4d51c6260686e38406955cac4a41
lib/com.ibm.ws.cdi.ejb.common_1.0.24.jar=a30d8ea18bbd41d498b1d6230406d4cd
lib/features/com.ibm.websphere.appserver.cdi1.2-ejb3.2.mf=cd2419bf93338a0bd930e80e62e83e49
