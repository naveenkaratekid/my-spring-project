#Fri Jan 25 02:42:31 GMT 2019
lib/features/com.ibm.websphere.appserver.microProfile-1.0.mf=31d6523cb4b864af5db0613d770dcef1
lib/com.ibm.ws.require.java8_1.0.24.jar=c8bbea2b91a087dbf95bbd66e7392c4d
