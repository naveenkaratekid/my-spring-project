#Fri Jan 25 02:42:31 GMT 2019
lib/com.ibm.ws.org.apache.aries.jndi.core_1.1.24.jar=8df5c4a212db52c34bbada38ddc8b327
lib/features/com.ibm.websphere.appserver.jndi-1.0.mf=ec1b277bf74d226f66a61d632a21fb2f
lib/com.ibm.ws.org.apache.aries.jndi.api_1.1.24.jar=1a0df7f8078641f6cc647eb3a5c8e514
lib/com.ibm.ws.jndi.url.contexts_1.0.24.jar=4370abce8b836152090206a4a68fde0d
lib/com.ibm.ws.jndi_1.0.24.jar=8179d91d08bd393055478d13094ce67d
