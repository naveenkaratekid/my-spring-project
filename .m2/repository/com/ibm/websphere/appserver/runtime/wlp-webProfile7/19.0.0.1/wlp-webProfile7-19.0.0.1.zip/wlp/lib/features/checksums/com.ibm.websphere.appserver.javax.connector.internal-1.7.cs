#Fri Jan 25 02:42:31 GMT 2019
dev/api/spec/com.ibm.websphere.javaee.connector.1.7_1.0.24.jar=fa29f0f438e16f6732e1450b85c25e88
lib/features/com.ibm.websphere.appserver.javax.connector.internal-1.7.mf=a582fb09a054f8caf86e9451f1c659ab
