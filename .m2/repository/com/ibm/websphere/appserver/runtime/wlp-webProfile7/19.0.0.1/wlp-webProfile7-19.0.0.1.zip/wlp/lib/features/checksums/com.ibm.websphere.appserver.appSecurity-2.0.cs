#Fri Jan 25 02:42:31 GMT 2019
lib/features/com.ibm.websphere.appserver.appSecurity-2.0.mf=444760a5ce28aff656b76a619c4bdee4
lib/com.ibm.ws.security.authentication.tai_1.0.24.jar=1212c15448ab02f51cfa6fd3d123b4e3
