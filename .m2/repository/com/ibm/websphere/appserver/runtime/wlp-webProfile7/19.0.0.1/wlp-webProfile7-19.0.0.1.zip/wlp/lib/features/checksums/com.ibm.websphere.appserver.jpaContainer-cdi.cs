#Fri Jan 25 02:42:30 GMT 2019
lib/features/com.ibm.websphere.appserver.jpaContainer-cdi.mf=9b7a6e138590abf972edb4387cd97213
lib/com.ibm.ws.jpa.container.v21.cdi_1.0.24.jar=a5a7d6ea74a5fd8648e0ef06b6591540
