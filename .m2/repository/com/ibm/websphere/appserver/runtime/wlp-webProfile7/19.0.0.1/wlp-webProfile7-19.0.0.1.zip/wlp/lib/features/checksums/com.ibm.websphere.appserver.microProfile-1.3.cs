#Fri Jan 25 02:42:31 GMT 2019
lib/features/com.ibm.websphere.appserver.microProfile-1.3.mf=8d80641e11b67124bf44f028ae98243a
lib/com.ibm.ws.require.java8_1.0.24.jar=c8bbea2b91a087dbf95bbd66e7392c4d
