#Fri Jan 25 02:42:30 GMT 2019
lib/features/com.ibm.websphere.appserver.org.eclipse.microprofile.rest.client-1.0.mf=217339fb87a4f93f467950ade3ee75a3
dev/api/stable/com.ibm.websphere.org.eclipse.microprofile.rest.client.1.0_1.0.24.jar=05e8a50bd7aae63928c31314234373fa
