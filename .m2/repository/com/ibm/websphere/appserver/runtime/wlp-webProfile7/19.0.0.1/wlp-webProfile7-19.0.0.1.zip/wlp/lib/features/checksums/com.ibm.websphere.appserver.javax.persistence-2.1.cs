#Fri Jan 25 02:42:31 GMT 2019
dev/api/spec/com.ibm.websphere.javaee.persistence.2.1_1.0.24.jar=f6798468cad13292f619d34195b4105c
lib/com.ibm.ws.javaee.persistence.api.2.1_1.0.24.jar=57c51aed8177eb27455eab58d43b88de
lib/features/com.ibm.websphere.appserver.javax.persistence-2.1.mf=e7eed4775736d659d245b5ff5aa64929
