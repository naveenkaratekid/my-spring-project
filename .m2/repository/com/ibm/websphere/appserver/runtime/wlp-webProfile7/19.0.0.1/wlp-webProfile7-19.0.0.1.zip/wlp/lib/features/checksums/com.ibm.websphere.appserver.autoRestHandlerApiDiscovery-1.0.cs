#Fri Jan 25 02:42:29 GMT 2019
lib/features/com.ibm.websphere.appserver.autoRestHandlerApiDiscovery-1.0.mf=87e5d8630e1ddf6ada0fc15ab4a48078
dev/spi/ibm/com.ibm.websphere.appserver.spi.restAPIDiscovery_2.0.24.jar=460992e08cc9391af2d665f630cac471
lib/com.ibm.websphere.rest.api.discovery_1.0.24.jar=0924f76872b6604167e846411764a42b
dev/spi/ibm/javadoc/com.ibm.websphere.appserver.spi.restAPIDiscovery_2.0-javadoc.zip=47dcb0a40e68336c812d8be5010e039f
