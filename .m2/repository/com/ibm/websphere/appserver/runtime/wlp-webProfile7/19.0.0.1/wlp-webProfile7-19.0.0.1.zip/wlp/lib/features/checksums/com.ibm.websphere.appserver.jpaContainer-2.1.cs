#Fri Jan 25 02:42:31 GMT 2019
lib/com.ibm.ws.jpa.container_1.0.24.jar=0ee9de5e6a228c8ec76c90aa4c35bc72
lib/com.ibm.ws.jpa.container.v21_1.0.24.jar=9bad4bf4cf440953cbc047ac427ea4d4
lib/features/com.ibm.websphere.appserver.jpaContainer-2.1.mf=221b1a8bd4d38abeca07ab4152c01a06
lib/com.ibm.ws.jpa.container.thirdparty_1.0.24.jar=e2e783097b97f9e6be8c4b3e288eb537
