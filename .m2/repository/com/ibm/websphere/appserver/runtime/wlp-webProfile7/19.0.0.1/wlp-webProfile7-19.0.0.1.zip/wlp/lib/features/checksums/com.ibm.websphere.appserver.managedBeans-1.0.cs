#Fri Jan 25 02:42:31 GMT 2019
dev/api/ibm/schema/ibm-managed-bean-bnd_1_0.xsd=3b0b778a121ff7c6c28f9e72afd96488
lib/com.ibm.ws.managedbeans_1.0.24.jar=4fbb05919dce145570f4e14f91c4e974
dev/api/ibm/schema/ibm-managed-bean-bnd_1_1.xsd=788164a7a6ea3fb24bb6106a48a9068b
lib/features/com.ibm.websphere.appserver.managedBeans-1.0.mf=14205b2aefc19b9cf719df8b759729ee
