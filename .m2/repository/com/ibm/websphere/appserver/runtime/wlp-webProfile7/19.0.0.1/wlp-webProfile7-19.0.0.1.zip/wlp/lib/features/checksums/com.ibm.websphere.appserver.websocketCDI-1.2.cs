#Fri Jan 25 02:42:29 GMT 2019
lib/com.ibm.ws.wsoc.cdi.weld_1.0.24.jar=eeb5c18080f0e1d49f1d52fbf4c60bab
lib/features/com.ibm.websphere.appserver.websocketCDI-1.2.mf=a4f89be4026261d05561d0b40943e40d
