#Fri Jan 25 02:42:31 GMT 2019
dev/api/spec/com.ibm.websphere.javaee.interceptor.1.2_1.0.24.jar=78655e147daabc8e85e0b9afe0f4a3be
lib/features/com.ibm.websphere.appserver.javax.interceptor-1.2.mf=32a892826b4a15599ff2c7e1c6d1eb1e
