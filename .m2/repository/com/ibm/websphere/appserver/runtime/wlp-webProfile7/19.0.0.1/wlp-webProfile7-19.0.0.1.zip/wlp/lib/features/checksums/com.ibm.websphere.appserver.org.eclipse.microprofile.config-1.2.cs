#Fri Jan 25 02:42:29 GMT 2019
lib/features/com.ibm.websphere.appserver.org.eclipse.microprofile.config-1.2.mf=23039e8fc1fee0498e37901ebfe4a477
dev/api/stable/com.ibm.websphere.org.eclipse.microprofile.config.1.2.1_1.0.24.jar=df523e9d03163cbae014e72b0c26ddbb
