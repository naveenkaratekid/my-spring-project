#Fri Jan 25 02:42:30 GMT 2019
lib/features/com.ibm.websphere.appserver.mpMetrics-monitor-1.0.mf=d08db2b28de99da73dc115e302fd6c6a
lib/com.ibm.ws.microprofile.metrics.monitor_1.0.24.jar=fccd4605966737be2749586f6aff17e6
