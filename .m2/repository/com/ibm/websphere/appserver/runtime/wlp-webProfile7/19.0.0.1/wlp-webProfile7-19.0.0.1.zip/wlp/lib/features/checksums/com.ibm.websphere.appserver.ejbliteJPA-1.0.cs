#Fri Jan 25 02:42:30 GMT 2019
lib/features/com.ibm.websphere.appserver.ejbliteJPA-1.0.mf=452fc32bf17ed7bc7aa8af4f8dcd396c
lib/com.ibm.ws.ejbcontainer.jpa_1.0.24.jar=8812e8bd58be0b17266f25b3bbe1d688
