#Fri Jan 25 02:42:29 GMT 2019
dev/api/spec/com.ibm.websphere.javaee.transaction.1.1_1.0.24.jar=fefc71aff4f53225da732bd6379d1a85
dev/api/ibm/com.ibm.websphere.appserver.api.transaction_1.1.24.jar=91604d75b7065b7e9c1e379943630e02
lib/features/com.ibm.websphere.appserver.jta-1.1.mf=ddf997c59bd78f0133babd922b3e6c55
dev/api/ibm/javadoc/com.ibm.websphere.appserver.api.transaction_1.1-javadoc.zip=72e7c2fb7dd122ff3bf1d3ff0361a0c9
