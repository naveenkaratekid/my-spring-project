#Fri Jan 25 02:42:30 GMT 2019
dev/api/ibm/com.ibm.websphere.appserver.api.security.spnego_1.0.24.jar=19498954d712feebd298b629366e4751
dev/api/ibm/javadoc/com.ibm.websphere.appserver.api.security.spnego_1.0-javadoc.zip=0772f3c227afb90c8d062b55625f25b5
lib/features/com.ibm.websphere.appserver.autoSecurity-1.0.mf=ee5bad98ae899300e024c1f7180398cb
