#Fri Jan 25 02:42:31 GMT 2019
dev/api/spec/com.ibm.websphere.javaee.validation.1.1_1.0.24.jar=9a8783a7706997061b72a0d3e7d31daf
lib/features/com.ibm.websphere.appserver.javax.validation-1.1.mf=60e715bc345ed3a2bb7eba9e6b9e6c47
