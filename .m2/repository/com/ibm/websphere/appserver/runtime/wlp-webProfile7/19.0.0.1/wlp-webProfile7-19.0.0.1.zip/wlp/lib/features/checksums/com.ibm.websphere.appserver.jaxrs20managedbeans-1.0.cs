#Fri Jan 25 02:42:31 GMT 2019
lib/features/com.ibm.websphere.appserver.jaxrs20managedbeans-1.0.mf=7f4b8bd3cc0e243abd952f617befb3ba
lib/com.ibm.ws.jaxrs.2.0.managedbeans_1.0.24.jar=79c97f962461de59fc3cfb7894c20fe6
