#Fri Jan 25 02:42:31 GMT 2019
lib/features/com.ibm.websphere.appserver.mpJwt-1.0.mf=cefe72916e445d26755613bd245e54f0
lib/com.ibm.ws.security.mp.jwt.cdi_1.0.24.jar=b803f7ee8559111b6e5186710447f296
dev/api/stable/com.ibm.websphere.org.eclipse.microprofile.jwt.1.0_1.0.24.jar=668d50f2630b8d7504db57bbc38a88ee
lib/com.ibm.ws.security.mp.jwt_1.0.24.jar=50001c294d20e007cb8f88027983e01e
