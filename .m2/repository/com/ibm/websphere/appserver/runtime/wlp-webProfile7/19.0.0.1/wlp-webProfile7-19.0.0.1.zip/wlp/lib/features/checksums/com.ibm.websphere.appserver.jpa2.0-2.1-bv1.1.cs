#Fri Jan 25 02:42:30 GMT 2019
lib/com.ibm.ws.jpa.container.beanvalidation.1.1_1.0.24.jar=57d142d3f3d0342152281d77dc8eeddf
lib/features/com.ibm.websphere.appserver.jpa2.0-2.1-bv1.1.mf=cb0501ca8bded65c78b8012c13e3f31f
