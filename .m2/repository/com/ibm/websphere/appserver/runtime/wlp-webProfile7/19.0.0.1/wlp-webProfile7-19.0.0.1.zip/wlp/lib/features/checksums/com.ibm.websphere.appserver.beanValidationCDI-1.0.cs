#Fri Jan 25 02:42:30 GMT 2019
lib/features/com.ibm.websphere.appserver.beanValidationCDI-1.0.mf=4a5242d15b1b27f8a591aba6fbbd4974
lib/com.ibm.ws.beanvalidation.v11.cdi_1.0.24.jar=3bd0515aa28f1de30cf66d36f29c60ef
