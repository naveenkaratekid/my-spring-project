#Fri Jan 25 02:42:30 GMT 2019
lib/features/com.ibm.websphere.appserver.jta-1.2.mf=ba72646faa508b7ab4c24e4d002d0719
dev/api/spec/com.ibm.websphere.javaee.transaction.1.2_1.0.24.jar=6ac7ae9e043e3b4b44f4489ce268801d
dev/api/ibm/com.ibm.websphere.appserver.api.transaction_1.1.24.jar=91604d75b7065b7e9c1e379943630e02
dev/api/ibm/javadoc/com.ibm.websphere.appserver.api.transaction_1.1-javadoc.zip=72e7c2fb7dd122ff3bf1d3ff0361a0c9
