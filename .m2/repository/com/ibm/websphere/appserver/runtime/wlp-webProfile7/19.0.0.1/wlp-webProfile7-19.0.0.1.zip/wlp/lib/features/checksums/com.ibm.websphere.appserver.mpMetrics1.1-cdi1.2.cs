#Fri Jan 25 02:42:30 GMT 2019
lib/features/com.ibm.websphere.appserver.mpMetrics1.1-cdi1.2.mf=4d6055e556cc2db785e905d6a4d12fec
lib/com.ibm.ws.microprofile.metrics.1.1.cdi_1.0.24.jar=d964c9b5f2f9220bae202b47bd1bdaff
