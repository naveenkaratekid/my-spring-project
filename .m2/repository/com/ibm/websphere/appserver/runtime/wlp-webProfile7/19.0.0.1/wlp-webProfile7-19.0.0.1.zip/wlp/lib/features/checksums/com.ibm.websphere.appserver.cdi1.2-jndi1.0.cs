#Fri Jan 25 02:42:30 GMT 2019
lib/com.ibm.ws.cdi.jndi_1.0.24.jar=b92b15ba69f3a3068f7ac9d75f549614
lib/features/com.ibm.websphere.appserver.cdi1.2-jndi1.0.mf=ff8a9cd884d2605770eeca3d92153ca9
