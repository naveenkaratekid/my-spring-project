#Fri Jan 25 02:42:31 GMT 2019
dev/api/spec/com.ibm.websphere.javaee.cdi.1.2_1.2.24.jar=03e76ffe158a116514d9a73a76683798
lib/features/com.ibm.websphere.appserver.javax.cdi-1.2.mf=fa0f19ce3e2cba8694e96c335ef563c0
