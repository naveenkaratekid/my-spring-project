#Fri Jan 25 02:42:30 GMT 2019
lib/com.ibm.ws.javaee.platform.v7.jndi_1.0.24.jar=5a0ca779177d12be886802162b0ced23
lib/features/com.ibm.websphere.appserver.javaeePlatform7.0-jndi1.0.mf=e5d255cfc7e07a4125ff17481938aac4
