#Fri Jan 25 02:42:31 GMT 2019
lib/features/com.ibm.websphere.appserver.jaxrscdi-2.0.mf=5166c5dd83a363671f377fba0bb540bb
lib/com.ibm.ws.jaxrs.2.0.cdi_1.0.24.jar=2144824aa546438cfc329dae727f7e60
