#Fri Jan 25 02:42:30 GMT 2019
dev/api/stable/com.ibm.websphere.org.eclipse.microprofile.metrics.1.1.1_1.0.24.jar=df945cbfaf3fa53efcc4a75263604841
lib/features/com.ibm.websphere.appserver.org.eclipse.microprofile.metrics-1.1.mf=b33f2986b63ac11b436d70de1bed4b17
